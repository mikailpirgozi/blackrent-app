-- BlackRent Database Backup
-- Created: 2025-09-03T23:24:11.362Z
-- Tables: 51


-- Štruktúra tabuľky: vehicle_unavailability_backup
-- Štruktúra tabuľky vehicle_unavailability_backup nedostupná


-- Dáta tabuľky: vehicle_unavailability_backup (4 záznamov)
-- COPY vehicle_unavailability_backup FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: insurance_claims
-- Štruktúra tabuľky insurance_claims nedostupná


-- Tabuľka insurance_claims je prázdna

-- Štruktúra tabuľky: company_investors
-- Štruktúra tabuľky company_investors nedostupná


-- Dáta tabuľky: company_investors (8 záznamov)
-- COPY company_investors FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: insurers
-- Štruktúra tabuľky insurers nedostupná


-- Dáta tabuľky: insurers (3 záznamov)
-- COPY insurers FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: organizations
-- Štruktúra tabuľky organizations nedostupná


-- Dáta tabuľky: organizations (1 záznamov)
-- COPY organizations FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: departments
-- Štruktúra tabuľky departments nedostupná


-- Dáta tabuľky: departments (4 záznamov)
-- COPY departments FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: customers
-- Štruktúra tabuľky customers nedostupná


-- Dáta tabuľky: customers (367 záznamov)
-- COPY customers FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: automatic_processing_log
-- Štruktúra tabuľky automatic_processing_log nedostupná


-- Tabuľka automatic_processing_log je prázdna

-- Štruktúra tabuľky: vehicle_unavailability
-- Štruktúra tabuľky vehicle_unavailability nedostupná


-- Dáta tabuľky: vehicle_unavailability (6 záznamov)
-- COPY vehicle_unavailability FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: user_permissions
-- Štruktúra tabuľky user_permissions nedostupná


-- Dáta tabuľky: user_permissions (17 záznamov)
-- COPY user_permissions FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: protocols
-- Štruktúra tabuľky protocols nedostupná


-- Tabuľka protocols je prázdna

-- Štruktúra tabuľky: customers_backup
-- Štruktúra tabuľky customers_backup nedostupná


-- Tabuľka customers_backup je prázdna

-- Štruktúra tabuľky: roles
-- Štruktúra tabuľky roles nedostupná


-- Dáta tabuľky: roles (7 záznamov)
-- COPY roles FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: vehicle_ownership_history
-- Štruktúra tabuľky vehicle_ownership_history nedostupná


-- Dáta tabuľky: vehicle_ownership_history (110 záznamov)
-- COPY vehicle_ownership_history FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: settlements
-- Štruktúra tabuľky settlements nedostupná


-- Dáta tabuľky: settlements (4 záznamov)
-- COPY settlements FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: email_blacklist
-- Štruktúra tabuľky email_blacklist nedostupná


-- Dáta tabuľky: email_blacklist (5 záznamov)
-- COPY email_blacklist FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: migration_history
-- Štruktúra tabuľky migration_history nedostupná


-- Dáta tabuľky: migration_history (1 záznamov)
-- COPY migration_history FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: pdf_protocols
-- Štruktúra tabuľky pdf_protocols nedostupná


-- Tabuľka pdf_protocols je prázdna

-- Štruktúra tabuľky: users_advanced
-- Štruktúra tabuľky users_advanced nedostupná


-- Dáta tabuľky: users_advanced (3 záznamov)
-- COPY users_advanced FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: teams
-- Štruktúra tabuľky teams nedostupná


-- Dáta tabuľky: teams (3 záznamov)
-- COPY teams FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: team_members
-- Štruktúra tabuľky team_members nedostupná


-- Tabuľka team_members je prázdna

-- Štruktúra tabuľky: company_investor_shares
-- Štruktúra tabuľky company_investor_shares nedostupná


-- Dáta tabuľky: company_investor_shares (19 záznamov)
-- COPY company_investor_shares FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: user_permissions_cache
-- Štruktúra tabuľky user_permissions_cache nedostupná


-- Tabuľka user_permissions_cache je prázdna

-- Štruktúra tabuľky: user_notification_preferences
-- Štruktúra tabuľky user_notification_preferences nedostupná


-- Tabuľka user_notification_preferences je prázdna

-- Štruktúra tabuľky: email_action_logs
-- Štruktúra tabuľky email_action_logs nedostupná


-- Dáta tabuľky: email_action_logs (71 záznamov)
-- COPY email_action_logs FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: vehicle_documents_backup
-- Štruktúra tabuľky vehicle_documents_backup nedostupná


-- Tabuľka vehicle_documents_backup je prázdna

-- Štruktúra tabuľky: vehicles
-- Štruktúra tabuľky vehicles nedostupná


-- Dáta tabuľky: vehicles (102 záznamov)
-- COPY vehicles FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: vehicle_documents
-- Štruktúra tabuľky vehicle_documents nedostupná


-- Dáta tabuľky: vehicle_documents (209 záznamov)
-- COPY vehicle_documents FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: expenses
-- Štruktúra tabuľky expenses nedostupná


-- Dáta tabuľky: expenses (487 záznamov)
-- COPY expenses FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: user_sessions
-- Štruktúra tabuľky user_sessions nedostupná


-- Tabuľka user_sessions je prázdna

-- Štruktúra tabuľky: insurances
-- Štruktúra tabuľky insurances nedostupná


-- Dáta tabuľky: insurances (4 záznamov)
-- COPY insurances FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: expense_categories
-- Štruktúra tabuľky expense_categories nedostupná


-- Dáta tabuľky: expense_categories (14 záznamov)
-- COPY expense_categories FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: recurring_expenses
-- Štruktúra tabuľky recurring_expenses nedostupná


-- Tabuľka recurring_expenses je prázdna

-- Štruktúra tabuľky: rental_backups
-- Štruktúra tabuľky rental_backups nedostupná


-- Dáta tabuľky: rental_backups (55 záznamov)
-- COPY rental_backups FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: companies
-- Štruktúra tabuľky companies nedostupná


-- Dáta tabuľky: companies (45 záznamov)
-- COPY companies FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: complete_backup_20250823
-- Štruktúra tabuľky complete_backup_20250823 nedostupná


-- Dáta tabuľky: complete_backup_20250823 (7 záznamov)
-- COPY complete_backup_20250823 FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: rentals
-- Štruktúra tabuľky rentals nedostupná


-- Dáta tabuľky: rentals (544 záznamov)
-- COPY rentals FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: company_documents
-- Štruktúra tabuľky company_documents nedostupná


-- Tabuľka company_documents je prázdna

-- Štruktúra tabuľky: flexible_rentals_backup_20250819
-- Štruktúra tabuľky flexible_rentals_backup_20250819 nedostupná


-- Tabuľka flexible_rentals_backup_20250819 je prázdna

-- Štruktúra tabuľky: email_processing_history
-- Štruktúra tabuľky email_processing_history nedostupná


-- Dáta tabuľky: email_processing_history (32 záznamov)
-- COPY email_processing_history FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: vehicles_backup_20250823
-- Štruktúra tabuľky vehicles_backup_20250823 nedostupná


-- Dáta tabuľky: vehicles_backup_20250823 (125 záznamov)
-- COPY vehicles_backup_20250823 FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: rentals_backup_20250823
-- Štruktúra tabuľky rentals_backup_20250823 nedostupná


-- Dáta tabuľky: rentals_backup_20250823 (874 záznamov)
-- COPY rentals_backup_20250823 FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: photo_metadata_v2
-- Štruktúra tabuľky photo_metadata_v2 nedostupná


-- Tabuľka photo_metadata_v2 je prázdna

-- Štruktúra tabuľky: photo_derivatives
-- Štruktúra tabuľky photo_derivatives nedostupná


-- Tabuľka photo_derivatives je prázdna

-- Štruktúra tabuľky: recurring_expense_generations
-- Štruktúra tabuľky recurring_expense_generations nedostupná


-- Tabuľka recurring_expense_generations je prázdna

-- Štruktúra tabuľky: protocol_processing_jobs
-- Štruktúra tabuľky protocol_processing_jobs nedostupná


-- Tabuľka protocol_processing_jobs je prázdna

-- Štruktúra tabuľky: feature_flags
-- Štruktúra tabuľky feature_flags nedostupná


-- Dáta tabuľky: feature_flags (4 záznamov)
-- COPY feature_flags FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: protocol_versions
-- Štruktúra tabuľky protocol_versions nedostupná


-- Tabuľka protocol_versions je prázdna

-- Štruktúra tabuľky: users
-- Štruktúra tabuľky users nedostupná


-- Dáta tabuľky: users (10 záznamov)
-- COPY users FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: return_protocols
-- Štruktúra tabuľky return_protocols nedostupná


-- Dáta tabuľky: return_protocols (15 záznamov)
-- COPY return_protocols FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií

-- Štruktúra tabuľky: handover_protocols
-- Štruktúra tabuľky handover_protocols nedostupná


-- Dáta tabuľky: handover_protocols (28 záznamov)
-- COPY handover_protocols FROM STDIN;
-- Poznámka: Dáta nie sú exportované kvôli kompatibilite verzií
