-- Railway BlackRent Database Backup
-- Created: Thu Sep  4 01:11:59 CEST 2025
-- Host: trolley.proxy.rlwy.net:13400

 Table: automatic_processing_log
 Table: companies
 Table: company_documents
 Table: company_investor_shares
 Table: company_investors
 Table: complete_backup_20250823
 Table: customers
 Table: customers_backup
 Table: departments
 Table: email_action_logs
 Table: email_blacklist
 Table: email_processing_history
 Table: expense_categories
 Table: expenses
 Table: feature_flags
 Table: flexible_rentals_backup_20250819
 Table: handover_protocols
 Table: insurance_claims
 Table: insurances
 Table: insurers
 Table: migration_history
 Table: organizations
 Table: pdf_protocols
 Table: photo_derivatives
 Table: photo_metadata_v2
 Table: protocol_processing_jobs
 Table: protocol_versions
 Table: protocols
 Table: recurring_expense_generations
 Table: recurring_expenses
 Table: rental_backups
 Table: rentals
 Table: rentals_backup_20250823
 Table: return_protocols
 Table: roles
 Table: settlements
 Table: team_members
 Table: teams
 Table: user_notification_preferences
 Table: user_permissions
 Table: user_permissions_cache
 Table: user_sessions
 Table: users
 Table: users_advanced
 Table: vehicle_documents
 Table: vehicle_documents_backup
 Table: vehicle_ownership_history
 Table: vehicle_unavailability
 Table: vehicle_unavailability_backup
 Table: vehicles
 Table: vehicles_backup_20250823


-- Database Statistics
Vehicles:             102
Vehicles: 
Companies:               45
Companies: 
Rentals:            544
Rentals: 
